/* *****************************************************************************
**
**	Module:		drvGsIp16ADC.h
**	Purpose:	Header file for GreenSpring IP-16ADC analog input board
**
**		This header file is based loosely on Kay-Uwe Kasemir's
**		4-9-96 code.  The major changes made involved separating
**		as much as possible from the carrier board code and
**		inserting it into each modules code.
**		This file contains the memory mapping of the module registers,
**		manifest constants, and function prototypes.
**
**     	This include file needs to be referenced in IP-16ADC
**		written by GAD beginning on 5/26/98.
**
**
**
**
** *****************************************************************************
**
**	Written By:		G.A. Domer, AlliedSignal FM&T
**	Started On:		05/26/98
**	Project Title:		EPICS - Driver
**	Commissioned by:	LANL
**
** *****************************************************************************
**
**	  Date		Revisor	Ver #	Modification Description
**	________	_______	_____  	_________________________________________
**
**	05/26/98	  GAD			Original.
**	06/04/98	  GAD			Changed driver task priority to 230 from 32
**	06/08/98	  GAD			Removed all references to ticks and semaphores.
**	07/27/98	  GAD			Removed all pertaining to interrupts.
**  02/24/99      GAD           Added capabitlity to bypass filtering of a channel by putting
**                              a 'u' at the end of the options string for stating the range
**                              in the database.
**
**
**
**
**
**
**
**
**
**
** ****************************************************************************/

#include <drvGsIPIC.h>
#include <taskLib.h>
#include <task_params.h>

/*
 *	If the driver's task parameters are not already defined
 *	in <task_params.h>, define them here:
 */
#ifndef IP16ADC_NAME

#define IP16ADC_NAME		"drvIp16ADC"
#define IP16ADC_PRI         75  /* IP16-ADC driver task - priority 75 */
#define IP16ADC_OPT			VX_FP_TASK | VX_STDIO
#define IP16ADC_STK			2000

#endif
/*  Constants used for digital 2 pole Butterworth filter  20sample/sec and .1Hz corner */
#define NZEROS 2
#define NPOLES 2
#define GAIN   4.143204922e+03

/*
 *	IP-16 ADC register map
 *
 *	because there is a byte register, this structure
 *	is different for PC or VME bus!
 */
typedef struct {
/* $00 */	Word			ctrl_stat;	/* R/W, Control and Status */
/* $02 */	Byte pad0[2];
/* $04 */	Word			data;		/* R,   A/D data           */
/* $06 */	Byte pad1[2];

#ifdef PC_STYLE
/* $08 */	Byte			vector;		/* R/W, Vector             */
/* $09 */	Byte pad2;
#else
/* $08 */	Byte pad2;
/* $09 */	Byte			vector;		/* R/W, Vector             */
#endif

/* $0A */	Byte pad3[2];
/* $0C */	Word			trigger;	/* W,   Trigger            */
}	IP16ADCregs;

typedef enum {
    ip16_0_5,       /*  filtered   0 ..  5V */
    ip16_0_10,      /*  filtered   0 .. 10V */
    ip16_m5_5,      /*  filtered  -5 ..  5V */
    ip16_m10_10,     /*  filtered -10 .. 10V */
    ip16_0_5u,      /*  unfiltered   0 ..  5V */
    ip16_0_10u,     /*  unfiltered   0 .. 10V */
    ip16_m5_5u,     /*  unfiltered  -5 ..  5V */
    ip16_m10_10u    /*  unfiltered -10 .. 10V */
}   IP16ADC_V_range;

/* changed number of channels from 8 to 16 for single ended 1/15/98 gad */
#define IP16ADC_NUM_CHANNELS	16

/*
 *	information for one single IP module,
 *	internal driver usage only
 */
typedef struct {
    IP16ADC_V_range        range;
    int                    devinit;		/* set to non-zero when ip_16adc_init is */
											/* run for each card */
    Word                   base_cmd;        /* command register bits    */
    Word                   channel_cmd;
    int                    filtered[IP16ADC_NUM_CHANNELS];  /* Is the channel filtered? enum value */
    double                 xv[IP16ADC_NUM_CHANNELS][NZEROS+1], yv[IP16ADC_NUM_CHANNELS][NPOLES+1];
                                            /* xv and yv are the Butterworth filter arrays */
    Word                   data[IP16ADC_NUM_CHANNELS];
    volatile IP16ADCregs   *regs;
    IPIC_Info              *mod;			/* pointer into device array - initialized in ip16adc_init */
}    IP16ADC;

/*
 *	Control and Status Bits
 *  These constants are used to set/reset the bits.
 */
#define CS_CHGINTEN         (1 << 15)   /* Change Window Interrupt Enable (Active High) */
                                        /* Set active to enable the channel configuration
                                         * change. Set to Low in ISR after interrupt */
#define CS_DATINTEN         (1 << 14)   /* Data Interupt Enable (Active High) */
                                        /* Set active to enable channel read. Set to Low
                                         * in ISR after interrupt */
#define CS_NO_SWRESET       (1 << 13)   /* Calibration cycle status (Active Low) */
                                        /* Set to low during calibration. Calibration
                                         * complete when transistion from low to high */
#define CS_NOSTDBY          (1 << 13)   /* Software Reset (Active Low) */
                                        /* Set to low to reset A/D converter */
#define CS_SDL              (1 << 12)   /* Serial Data Latch (Active Low) */
                                        /* Set low when conversion complete (not used
                                         * in new code) */
#define CS_NO_CHGINTRQ      (1 << 11)   /* Change Window Interrupt Status (Active Low) */
                                        /* Set low when channel configuration is complete.
                                         * Set high when CHGINTEN is reset */
#define CS_NO_DATINTRQ      (1 << 10)   /* Data Available Interrupt Status (Active Low) */
                                        /* Set low when data conversion for current channel
                                         * complete. Set high when DATINTEN is reset */
#define CS_NO_FREERUN       (1 <<  8)   /* Freerun Continuous Capture (Active Low) */
                                        /* Set low to initiate continuous A/D conversions
                                         * (not used in current software) */
#define CS_BIPOLAR          (1 <<  6)   /* Input Polarity Selector (Bi-polar High) */
                                        /* (Unipolar Low) */
#define CS_UNITY_GAIN       (1 <<  5)   /* Gain Selection (Unity High) (Half Low) */
/*  The next two entries are used to set the multiplexer for SE and Diff channels
 *  and ODD/EVEN channels */
#define CS_INSL1            (1 <<  4)   /* Input Configuration Multiplexer MSB */
#define CS_INSL0            (1 <<  3)   /* Input Configruation Multiplexer LSB */

/*	input range */
#define CS_10_10V			CS_BIPOLAR
#define CS_0_10V			0
#define CS_5_5V				(CS_BIPOLAR | CS_UNITY_GAIN)
#define CS_0_5V				CS_UNITY_GAIN

/*	input channel select: c must be in [0..7] */
#define CS_DIFF_CHANNEL_SEL(c)	(CS_INSL1 | CS_INSL0 | (c))
/* add SE Channel selects 1/15/98 gad c must be in [0..15] */
#define CS_SEODD_CHANNEL_SEL(c)	(CS_INSL0 | (c))
#define CS_SEEVEN_CHANNEL_SEL(c) (CS_INSL1 | (c))
#define CS_GROUND_CALIB_SEL		0
#define CS_VREF_CALIB_SEL		1

/*
 *	device init function for card
 *	used calibrate 16DC card, set up intterrupts, and
 *  provide pointer to IP16ADC for device support
 */
IP16ADC *ip_16adc_init (short card, short signal, IP16ADC_V_range range);

/*
 *	driver init function for card
 *	used to find the card in the device array and allocate memory for the IP16ADC structure
 *
 */
long ip16adc_init (void);

/*
 *	initiate a hardware calibration
 *
 *	This takes some seconds,
 *	this routine is also called from ip16adc_init
 */
int ip16adc_calibrate (IP16ADC *ip);

/*
 *	Read data for given channel.
 *	If driver task is not running, restart it.
 *
 *	result: 0 = OK, 1: restarted driver, 2: error
 */
int ip16adc_get_channel (IP16ADC *ip, int channel, Word *data);

long ip_16adc_report (int level);

/*	EOF drvGsIp16ADC.h */

