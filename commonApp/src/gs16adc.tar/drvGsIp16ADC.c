/* *****************************************************************************
**
**	Module:		drvGsIp16ADC.c
**	Purpose:	Source code file for GreenSpring IP-16ADC analog input driver
**
**		This code file is based loosely on Kay-Uwe Kasemir's
**		5-15-96 code for the IP-16ADC board.  The major changes made
**		involved separating as much as possible from the carrier board
**		and inserting it into each modules code.  This file contains the
**		code to initialize and communicate with the 16ADC module.
**
**		The main purpose of this module is to initialize the structures and
**     	fill them for each 16ADC card in an IOC rack.  The module numbers start
**		from 0 and can be up to the IPIC_NUM_CARDS constant set in drvGsIPIC.h.
**		(Assuming 16ADC cards are the only ones in the rack.)  The modules are not
**		dependent in position on the carriers in the rack.  Module numbers are
**		assigned in order from lower address to higher address. (Address ranges
**		for IP modules, 4 modules/carrier, are 0x0000-0x0300 through 0xF000-0xF300.
**
**		NOTE:	Currently this driver was set up to do only single-ended channels.
**				Differential channels can be used by changing the channel select.
**				Adding an 'S' or a 'D' to the range in the channel specification
**				would be an effective way of handling, with 'S' being the default
**				when not specified.
**
**		Jumpers:
**
**		No jumpers are required for IP modules.  See drvGsIPIC.c for jumpers on
**		the carrier board.
**
** *****************************************************************************
**
**	Written By:		G.A. Domer, AlliedSignal FM&T
**	Started On:		05/01/98
**	Project Title:		EPICS - Driver
**	Commissioned by:	LANL
**
** *****************************************************************************
**
**	Functions Included:
**
**              IP16ADC *ip_16adc_init (short card, short signal, IP16ADC_V_range range);
**
**				long ip16adc_init(void);
**
**				int ip16adc_calibrate (IP16ADC *ip)
**
**              static void ip16adc_read (void)
**
**				int ip16adc_get_channel (IP16ADC *ip, int channel, Word *data)
**
**				long ip_16adc_report (int level);
**
** *****************************************************************************
**
**	  Date		Revisor	Ver #	Modification Description
**	________	_______	_____  	_________________________________________
**
**	05/01/98	  GAD	1.0		Original code
**	06/04/98	  GAD			Removed all delays on interrupt code and placed
**								spawned task at priority 230 to prevent takeover
**								of all CPU clock cycles.
**	06/08/98	  GAD			Removed all references to ticks and semaphores.
**	07/21/98	  GAD			Added taskDelay in ip16adc_IRQ_read and returned
**								zero from device init if calibration failed.
**  07/27/98	  GAD			Removed all interrupt driven code.  IP carrier
**								interrupt structure would require too much code.
**								Polling the interrupt flags on each IP module
**								was the chosen solution.
**  09/09/98     GAD            Corrected the test for the interrupt flag in
**                              ip16adc_read.  Was checking CS_CHGINTEN and
**                              CS_DATINTEN instead of CS_NO_CHGINTRQ and
**                              CS_DATINTRQ.  Added CS_NO_FREERUN to base command.
**  10/9/98       GAD           Removed assert from ip16ac_get_channel.  No benefit.
**                              Changed to if test.
**  01/15/99      GAD           Removed the polling of interrupt flags. Discovered
**                              that once an interrupt failed on an IP module, the
**                              interrupts stopped working.  Was seeing the loop counters
**                              counting out while waiting for the interrupts.
**  01/19/99     GAD            Added a 2 pole Butterworth lowpass filter to the analog input reads.
**                              At this revision a 20Hz sample rate with a .1Hz corner frequency
**                              were used to design the filter.  Constants were generated at the
**                              "Interactive Digital Filter Design" website at url
**                              "http://www.cs.york.ac.uk/~fisher/mkfilter/".  Was also able
**                              to change priority to 75 to ensure a periodic sampling.
**  02/24/99     GAD            Added capabitlity to bypass filtering of a channel by putting
**                              a 'u' at the end of the options string for stating the range
**                              in the database.
**
**
** ****************************************************************************/

#include <vxWorks.h>
#include <sysLib.h>
#include <vme.h>
#include <iv.h>
#include <drvGsIp16ADC.h>
#include <devLib.h>
#include <drvSup.h>

/**/
/***********\
** entry functions for EPICS to point to local functions
\**********/
static long init(){
	ip16adc_init();
	return(0);
}

static long report(int level){
	ip_16adc_report(level);
	return(0);
}

/* array of structure pointers to hold information about each 16ADC module */
static IP16ADC	*ip16adc_card[IPIC_NUM_CARDS];

static int drvinit=0;	/* flag to indicate whether the driver init
						function has run once */
static int driver_task=0;  /* holds task id of the task that reads the modules - added
                           when trying to read all modules from one task */
static int cards_found=0;   /* holds the number of cards found during initialization */

/**/
/***********\
**
**  FUNCTION:       ip_16adc_report - EPICS driver report function
**
**  SYNTAX:         long ip_16adc_report(int type)
**
**  ARGUMENTS:      int type - <= 1 ==> card location only
**							 - > 1 ==> all info for card
**
**  RETURN VALUES:  0 - (OK)
**
**  DESCRIPTION:    This function can be called from the VxWorks IOC prompt and
**                  as part of the EPICS driver-table call via dbior().  It
**					displays the IP-16ADC modules installed and information about
**					those modules.
**
\**********/
long ip_16adc_report (int level) {
	int	card, j;

    for (card=0; card<cards_found; ++card) {
		if (ip16adc_card[card])	{
			printf ("card #%d at 0x%04X\n", card, ip16adc_card[card]->mod->base);
			if (level > 1) {

				switch (ip16adc_card[card]->range) {
                    case ip16_0_5u:
                    case ip16_0_5:
                                        printf ("\tinput range: 0..5 V\n");
                                        break;
                    case ip16_0_10u:
                    case ip16_0_10:
                                        printf ("\tinput range: 0..10 V\n");
                                        break;
                    case ip16_m5_5u:
                    case ip16_m5_5:
                                        printf ("\tinput range: -5..5 V\n");
                                        break;
                    case ip16_m10_10u:
                    case ip16_m10_10:
                                        printf ("\tinput range: -10..10 V\n");
                                        break;
				}

				for (j=0; j<IP16ADC_NUM_CHANNELS; ++j)
                    printf ("\tch. %d data: 0x%04X (%d)\n",
                        j, ip16adc_card[card]->data[j], ip16adc_card[card]->data[j]);
			}
		}
	}

	return 0;
}

/**/
/***********\
**
**  FUNCTION:       ip16adc_calibrate - EPICS driver calibrate analog inputs
**
**  SYNTAX:         int ip16adc_calibrate (IP16ADC *ip)
**
**  ARGUMENTS:      IP16ADC *ip - pointer to structure for the module
**
**  RETURN VALUES:  0 - (OK)
**					1 - error
**
**  DESCRIPTION:    This function is called from ip16adc_init.  It will
**					initiate a hardware	calibration of the IP-16ADC module.
**
\**********/
int ip16adc_calibrate (IP16ADC *ip)	{
	int		quartsec = sysClkRateGet() / 4;
	int		interval = 0;

	if (!ip->devinit) {	/* don't run is card is already initialized */
#define PATIENCE	42 /* ! */

        /*  issue "reset" signal for hardware calibration */
        /* set write only Bit 13 to 0 to reset A/D  */
		ip->regs->ctrl_stat = (ip->base_cmd| CS_SEODD_CHANNEL_SEL(0)) & (~CS_NO_SWRESET);
		taskDelay (1);
		/* start calibration by setting write only Bit 13 to 1  */
		ip->regs->ctrl_stat = ip->base_cmd| CS_SEODD_CHANNEL_SEL(0);

		DEBUG( printf ("ip16adc_calibrate: hardware calibration "); )

		/* Look for read ony Bit 13 to change from 0 to 1 */
		while ((ip->regs->ctrl_stat & CS_NOSTDBY) == 0)	{
			++interval;
			if (interval > PATIENCE) {
				logMsg ("ip16adc_calibrate: never ending calibration? I Quit.\n");
				return 1;
			}
			taskDelay (quartsec);
		}
		DEBUG( printf ("ok after %lg secs.\n", (double) interval/4.0); )

		/* Reset control register so that Bit 13 is a 1 */
		ip->regs->ctrl_stat = ip->base_cmd| CS_SEODD_CHANNEL_SEL(0) | CS_NO_FREERUN;
#undef PATIENCE
	}
	return 0;
}


/**/
/***********\
**
**  FUNCTION:       ip16adc_read - EPICS driver read routine
**
**  SYNTAX:         static void ip16adc_read (IP16ADC *ip)
**
**  ARGUMENTS:      IP16ADC *ip - pointer to structure for the module
**
**  RETURN VALUES:  none
**
**  DESCRIPTION:    This function is spawned from ip16adc_get_channel to initiate
**                  conversions on all 16 channels.  It sets channel, reads them
**                  and applies a filter if the channel information ends in a 'u'.
**                  This function used to trigger the interrupts so the channel
**                  could be read via the ISR.  (Could not get interrupts to work
**                  properly).  This function now sets the board into freerun after
**                  the channel configuration, waits for 1/4 of the delay time,
**                  stops the freerun, waits for 1/4 of the delay time, reads the
**                  channels, then waits for the remaining 1/2 of the delay time.
**                  All channels of the same number are read at once and the data
**                  is placed in a local array to be retruned by ip16adc_get_channel.
\**********/
static void ip16adc_read (void) {
    int ii;
    int card;
    double local_store;                 /* local variable reading */
    IP16ADC *ip;
    Word chan_cmd[16];  /* keeps all 16 channel configurations for reads */

    /* Set up all of the channel commands so that we don't have to do it every time */
    for (ii=0;ii<IP16ADC_NUM_CHANNELS;ii++) {
        if (ii & 1)         /* check for ODD or EVEN SE channel */
            chan_cmd[ii] = CS_SEEVEN_CHANNEL_SEL(((ii)-1)/2);
        else
            chan_cmd[ii] = CS_SEODD_CHANNEL_SEL((ii)/2);
    }

    while(1) {

        for (ii=0;ii<IP16ADC_NUM_CHANNELS;ii++) {
            for (card=0; card<cards_found; card++) {
                ip = ip16adc_card[card];
                /* set up next channel in control/status register */
#if NOTFREERUN
                ip->channel_cmd = ip->base_cmd | chan_cmd[ii] | CS_NO_FREERUN;
#else
                /* set upt next channel in FREERUN mode */
                ip->channel_cmd = (ip->base_cmd | chan_cmd[ii]) & 0xFEFF;
#endif
                ip->regs->ctrl_stat = ip->channel_cmd;
                /* trigger the channel configuration change */
                ip->regs->trigger   = 0xFFFF;
            }
#if NOTFREERUN
            for (card=0; card<cards_found; card++) {
                ip = ip16adc_card[card];
                /* trigger the data read */
                ip->regs->trigger = 0xFFFF;
            }
#else
            taskDelay(sysClkRateGet() / 1280);   /* Task delay gives one-fourth of the
                                                  * periodic sampling needed for filtering
                                                  * after all sixteen channels have been read.
                                                  * (.78125 msec * 16 => 12.5 msec)  */
            for (card=0; card<cards_found; card++) {
                ip = ip16adc_card[card];
                /* turn off FREERUN mode */
                ip->channel_cmd = ip->base_cmd | chan_cmd[ii] | CS_NO_FREERUN;
            }
            taskDelay(sysClkRateGet() / 1280);   /* Task delay gives one-fourth of the
                                                  * periodic sampling needed for filtering
                                                  * after all sixteen channels have been read.
                                                  * (.78125 msec * 16 => 12.5 msec)  */
#endif
            for (card=0; card<cards_found; card++) {
                /* read the data */
                ip = ip16adc_card[card];
                if ( ip->filtered[ii] > ip16_m10_10 ) {  /* don't filter if greater */
                    ip->data[ii] = ip->regs->data;
                }

                else {
                    local_store = (double)ip->regs->data;
                    /* Send the data through a 2-pole Butterworth filter */
                    ip->xv[ii][0] = ip->xv[ii][1];
                    ip->xv[ii][1] = ip->xv[ii][2];
                    ip->xv[ii][2] = local_store / GAIN;
                    ip->yv[ii][0] = ip->yv[ii][1];
                    ip->yv[ii][1] = ip->yv[ii][2];
                    if ((ip->yv[ii][2] =   (ip->xv[ii][0] + ip->xv[ii][2])
                                + (2.0 * ip->xv[ii][1])
                                + (  (-0.9565436765) * ip->yv[ii][0]) + ( 1.9555782403 * ip->yv[ii][1])) < 0.0) {
                        ip->yv[ii][2] = 0.0;
                    }
                    if ( ip->yv[ii][2] > 65535.0 ) {
                        ip->yv[ii][2] = 65535.0;
                    }
                    ip->data[ii] = (Word)(ip->yv[ii][2]);
                }
            }
        }
        /* Task delays (50msec) provide approximately a 20 sample/sec rate */
#if NOTFREERUN
        taskDelay(sysClkRateGet() / 20);   /* Task delay gives periodic sampling needed for filtering  */
#else
        taskDelay(sysClkRateGet() / 40);   /* Task delay gives half of the periodic sampling
                                            * needed for filtering  (25 msec) */
#endif
    }
}

/**/
/***********\
**
**  FUNCTION:       ip16adc_get_channel - EPICS driver get channel data routine
**
**  SYNTAX:         int ip16adc_get_channel (IP16ADC *ip, int channel, Word *data))
**
**  ARGUMENTS:      IP16ADC *ip - pointer to structure for the module
**					int channel - channel number
**					Word *data	- pointer to channel access data location
**
**  RETURN VALUES:	0 = OK
**					1 = driver started/restarted
**					2 = error
**
**  DESCRIPTION:    This function is spawns ip16adc_read and returns the
**					data contained in the local data array back to channel
**					access device support function, read_ai for the given channel.
\**********/
int ip16adc_get_channel (IP16ADC *ip, int channel, Word *data) {


	if (channel >= 0   &&   channel <= IP16ADC_NUM_CHANNELS){

        if (taskIdVerify (driver_task) == ERROR) {
			/* add a task to read the channels and fill a global area  */
            driver_task = taskSpawn (IP16ADC_NAME, IP16ADC_PRI, IP16ADC_OPT, IP16ADC_STK,
                (FUNCPTR) ip16adc_read, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

			if (driver_task == ERROR) {
				logMsg ("ip16adc_init: channel read task could not be initialized");
				return 2;
			}
			return 1;
		}
        /* return the data for the requested channel */
		*data = ip->data[channel];
		return 0;
	}
	else
		return 2;
}


/**/
/***********\
**
**  FUNCTION:       ip16adc_init - EPICS driver IP initialization
**
**  SYNTAX:         long ip16adc_init (void)
**
**  ARGUMENTS:      none
**
**  RETURN VALUES:	0 = error
**
**  DESCRIPTION:    This function performs the driver initialization functions
**					for the IP module.
\**********/
long ip16adc_init (void) {
    IPIC_Info		*info,*devptr;
    void			*dummy;
    int             offset;

    if (!drvinit) {	/* first call for this card ? */


        /*	call IPIC_get_IPID to make sure that cards have been identified	*/
        if (! (info = IPIC_get_IPID ())) {
            logMsg ("ip16adc_init: no response from IPIC_get_IPID\n");
            return 0;
        }


/* check for the cards by reading the manufacturer id.  Keep track if I have already detected
   one by keeping the index with the structure.  Find all of the cards at once. */

        devptr=info;		/* use devptr as a working pointer into device structure */
        for (offset=0; offset<64; offset++,devptr++) {
            if (devptr->manufacturer == 0xF0) {	/* Greenspring manufacturing ID */
                if (devptr->model == 0x36) {	/* model number of 16ADC */

                    DEBUG(
                          printf ("ip16adc_init: found Greenspring IP-16ADC at 0x%X\n",
                                  devptr->base);
                         )

                    if (devRegisterAddress ("drvGsIp16ADC", atVMEA16, devptr->base,
                        /* size */0x100, &dummy)) {
                        logMsg ("ip16adc_init: cannot register base address");
                        return 0;
                    }

                    /* allocate memory for the card's structure */
                    if (! (ip16adc_card[cards_found] = (IP16ADC *) calloc (1, sizeof (IP16ADC)))) {
                        logMsg ("ip16adc_init: calloc (IP16ADC) failed\n");
                        return 0;
                    }

                    ip16adc_card[cards_found]->mod = devptr;
                    ip16adc_card[cards_found]->devinit=0;
                    ip16adc_card[cards_found]->regs = (IP16ADCregs *) devptr->local; /* base address of module */
                    cards_found++;
                }
            }
        }
        drvinit=1;
    }
    else {
        DEBUG(printf ("ip16adc_init: card #%d is already init.\n", cards_found);)
    }
    return 1;
}

/**/
/***********\
**
**  FUNCTION:       ip_16adc_init - EPICS driver IP device initialization
**
**  SYNTAX:         IP16ADC *ip_16adc_init (short card, shore signal, IP16ADC_V_range range)
**
**  ARGUMENTS:      short card    -   EPICS card number
**                  short signal  -   EPICS signal number
**					IP16ADC_V_range range - signal voltage range
**
**  RETURN VALUES:	0 = error
**					IP16ADC * = pointer to device strutures for card
**
**  DESCRIPTION:    This function performs the device initialization functions
**					for the IP module including the base command, calibration,
**					and interrupt setup.
\**********/
IP16ADC *ip_16adc_init (short card, short signal, IP16ADC_V_range range) {

    /* keep track if the channel is to be filtered or not */
    ip16adc_card[card]->filtered[signal] = range;

    if (!ip16adc_card[card]->devinit) {
		/* Create a base for the command register so that Bit 13 is a 1 and channel 0 is selected */
		/* removed Differential channel select Need to added SE wherever the base_cmd is used to */
		/* set channel 0 2/13/98 gad */
		/* NOTE:  An even EPICS signal maps to an odd 16ADC channel */
		/* ip16adc_card[card]->base_cmd    = CS_NO_SWRESET | CS_DIFF_CHANNEL_SEL(0); */
        ip16adc_card[card]->base_cmd    = CS_NO_SWRESET | CS_NO_FREERUN;
		ip16adc_card[card]->range      	= range;

		/* set Bit 5 and Bit 6 in the command register to reflect the range of the card */
		/* NOTE:  All channels for a card must be set to the same range in the EPICS database */
		switch (ip16adc_card[card]->range) {
            case ip16_0_5u:
            case ip16_0_5:
                                ip16adc_card[card]->base_cmd |= CS_0_5V;
								break;
            case ip16_0_10u:
            case ip16_0_10:
                                ip16adc_card[card]->base_cmd |= CS_0_10V;
								break;
            case ip16_m5_5u:
            case ip16_m5_5:
                                ip16adc_card[card]->base_cmd |= CS_5_5V;
								break;
            case ip16_m10_10u:
            case ip16_m10_10:
                                ip16adc_card[card]->base_cmd |= CS_10_10V;
								break;
        }

        ip16adc_calibrate(ip16adc_card[card]);
		ip16adc_card[card]->regs->ctrl_stat = ip16adc_card[card]->base_cmd| CS_SEODD_CHANNEL_SEL(0) | CS_NO_FREERUN;

	}
	else {
		DEBUG(
		printf ("ip_16adc_init: card #%d is already init.\n", card);
		)
	}

	ip16adc_card[card]->devinit = 1;	/* set flag to indicate that this has run */
  	return ip16adc_card[card];
}

struct {
	long	number;
	DRVSUPFUN	report;
	DRVSUPFUN	init;
}	drvGsIp16ADC = {
	2,
	(DRVSUPFUN) report,
	(DRVSUPFUN) init
};

/*	EOF drvGsIp16ADC.c */
